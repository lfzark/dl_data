from flask import Flask,request,Response
from flask import jsonify
app = Flask(__name__, static_folder='')
from postMaker import post_make
@app.route('/get_p')
def hello():
    avatar_url = request.args.get('avatar_url')
    uname = request.args.get('uname')
    #print post_make(r"https://img0.bdstatic.com/static/searchdetail/img/logo-2X_b99594a.png",r'testIcon.jpg',userName=u'dfdfdf')
    img_url =  post_make(avatar_url,r'testIcon.jpg',userName=uname)
    return jsonify({'img_url':img_url,'words':2})

@app.route("/image/<imageid>")
def index(imageid):
    image = file("./static/{}".format(imageid))
    resp = Response(image, mimetype="image/jpeg")
    return resp

app.run()
